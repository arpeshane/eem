/**
 * 
 */
/**
 * @author ajit.p
 *
 */
package com.nice.eem.exception;